Star Knightess Aura - Chinese Language Pack
============================================

INSTALL
-------
1. Drag the game folder onto install.bat
   (or run: install.bat "<game folder>")

2. Launch the game
3. Options -> Language -> select Chinese

The installer will:
  - back up languages/Languages.json
  - register CN in the language list
  - copy the CN language files
  - copy the Chinese fonts (Noto Sans SC)

UNINSTALL
---------
1. Rename languages/Languages.json.bak back to Languages.json
2. Delete the languages/CN folder

NOTES
-----
- The game data folder is NOT modified. Only the languages/
  folder is touched, so switching back to English is instant.
- Font: Noto Sans SC (SIL Open Font License 1.1)
