"""在 Languages.json 里注册 CN 语言。

独立成 .py 而非塞进 bat 的原因：bat 里的内联 Python 需要大量转义
（引号、百分号、尖括号），极易出错。

用法：python register_cn.py <Languages.json 路径>
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print("usage: register_cn.py <Languages.json>")
        return 1

    p = Path(argv[1])
    if not p.is_file():
        print(f"[FAIL] not found: {p}")
        return 1

    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"[FAIL] invalid JSON: {e}")
        return 1

    codes = data.get("codes")
    if not isinstance(codes, dict):
        print("[FAIL] no 'codes' key in Languages.json")
        return 1

    if "CN" in codes:
        print(f"      CN already present ({codes['CN']:.1%})")
        return 0

    # CN 语言在中文里的占比
    codes["CN"] = 0.0
    p.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print("      CN registered")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
