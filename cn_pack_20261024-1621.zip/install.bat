@echo off
setlocal
title Star Knightess Aura - Chinese Patch Installer

REM ---- Python interpreter used to register the CN language ----
set "PY=C:\Users\lht30\.workbuddy\binaries\python\envs\default\Scripts\python.exe"

echo.
echo ============================================
echo   Star Knightess Aura - Chinese Language Pack
echo ============================================
echo.

set "GAME=%~1"
if "%GAME%"=="" (
  echo Drag the game folder onto this file, or run:
  echo   install.bat followed by the full game folder path
  echo.
  pause
  exit /b 1
)

if not exist "%GAME%\languages\Languages.json" (
  echo [ERROR] Cannot find "%GAME%\languages\Languages.json"
  echo This does not look like Star Knightess Aura.
  echo.
  pause
  exit /b 1
)

echo Game folder: %GAME%
echo.

REM ---- 1. backup Languages.json ----
if not exist "%GAME%\languages\Languages.json.bak" (
  copy /Y "%GAME%\languages\Languages.json" "%GAME%\languages\Languages.json.bak" >nul
  if exist "%GAME%\languages\Languages.json.bak" (
    echo [1/4] Languages.json backed up
  ) else (
    echo [1/4] FAILED to backup Languages.json
    pause
    exit /b 1
  )
) else (
  echo [1/4] Languages.json already backed up, skip
)

REM ---- 2. register CN ----
echo [2/4] Registering CN language...
if not exist "%PY%" (
  echo [2/4] FAILED: Python not found at
  echo        %PY%
  echo.
  echo   This pack needs Python to edit Languages.json.
  echo   Install Python 3 and re-run, or edit Languages.json
  echo   manually by adding a "CN" entry to "codes".
  pause
  exit /b 1
)
"%PY%" "%~dp0register_cn.py" "%GAME%\languages\Languages.json"
if errorlevel 1 (
  echo [2/4] FAILED to register CN
  pause
  exit /b 1
)
echo       done

REM ---- 3. copy language files ----
echo [3/4] Copying CN language files...
REM robocopy is more reliable than xcopy here:
REM   /IS   include same files (ensure old content is overwritten)
REM   exit code below 8 means success
REM   NOTE: do not write angle brackets in REM lines, cmd still parses them
robocopy "%~dp0CN" "%GAME%\languages\CN" /E /IS /NFL /NDL /NJH /NJS /NP >nul 2>&1
if errorlevel 8 (
  echo [3/4] FAILED to copy files - robocopy error %errorlevel%
  pause
  exit /b 1
)
if not exist "%GAME%\languages\CN\Actors.json" (
  echo [3/4] FAILED: Actors.json not found after copy
  pause
  exit /b 1
)
echo       done

REM ---- 4. copy fonts ----
echo [4/4] Copying Chinese fonts...
if exist "%~dp0CN\fonts" (
  if not exist "%GAME%\fonts" mkdir "%GAME%\fonts" >nul 2>&1
  robocopy "%~dp0CN\fonts" "%GAME%\fonts" *.otf /IS /NFL /NDL /NJH /NJS /NP >nul 2>&1
  echo       done
) else (
  echo       skipped - no fonts in pack
)

echo.
echo ============================================
echo   INSTALL COMPLETE
echo.
echo   Launch the game, then:
echo     Options - Language - select Chinese
echo.
echo   If Chinese shows as empty boxes, the font
echo   was not installed properly.
echo.
echo   To undo: rename Languages.json.bak back to
echo   Languages.json and delete the CN folder.
echo ============================================
pause
